<?php $__env->startSection('title', 'Edit Produk | GiftKita Seller'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto py-8">
    <div class="bg-white shadow-md rounded-xl p-6 border border-gray-100">
        <h2 class="text-2xl font-bold text-gray-800 mb-6">✏️ Edit Produk</h2>

        
        <?php if(session('success')): ?>
            <div class="bg-green-100 border border-green-300 text-green-800 p-3 rounded mb-4">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        
        <form action="<?php echo e(route('penjual.produk.update', $produk->id)); ?>" method="POST" enctype="multipart/form-data" class="space-y-5">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            
            <div>
                <label for="toko_id" class="block text-gray-700 font-semibold mb-1">Toko</label>
                <select id="toko_id" name="toko_id"
                        class="w-full border-gray-300 rounded-lg focus:ring-[#007daf] focus:border-[#007daf]"
                        required>
                    <?php $__currentLoopData = $tokos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $toko): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($toko->id); ?>" <?php echo e($produk->toko_id == $toko->id ? 'selected' : ''); ?>>
                            <?php echo e($toko->nama_toko); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['toko_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div>
                <label for="nama" class="block text-gray-700 font-semibold mb-1">Nama Produk</label>
                <input type="text" id="nama" name="nama"
                       value="<?php echo e(old('nama', $produk->nama)); ?>"
                       class="w-full border-gray-300 rounded-lg focus:ring-[#007daf] focus:border-[#007daf]"
                       required>
                <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div>
                <label for="kategori_id" class="block text-gray-700 font-semibold mb-1">Kategori</label>
                <select id="kategori_id" name="kategori_id"
                        class="w-full border-gray-300 rounded-lg focus:ring-[#007daf] focus:border-[#007daf]"
                        required>
                    <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($kategori->id); ?>" <?php echo e($produk->kategori_id == $kategori->id ? 'selected' : ''); ?>>
                            <?php echo e($kategori->nama_kategori); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['kategori_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div>
                <label for="deskripsi" class="block text-gray-700 font-semibold mb-1">Deskripsi</label>
                <textarea id="deskripsi" name="deskripsi" rows="4"
                          class="w-full border-gray-300 rounded-lg focus:ring-[#007daf] focus:border-[#007daf]"><?php echo e(old('deskripsi', $produk->deskripsi)); ?></textarea>
                <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div>
                <label class="block text-gray-700 font-semibold mb-1">File Produk Lama</label>
                <div class="flex flex-wrap gap-4">
                    <?php $__empty_1 = true; $__currentLoopData = $produk->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $ext = pathinfo($file->filepath, PATHINFO_EXTENSION);
                            $isVideo = in_array(strtolower($ext), ['mp4','webm','avi','mov']);
                        ?>

                        <div class="relative w-36">
                            <?php if($isVideo): ?>
                                <video width="140" height="100" controls class="rounded-md border border-gray-200 object-cover">
                                    <source src="<?php echo e(asset('storage/'.$file->filepath)); ?>">
                                </video>
                            <?php else: ?>
                                <img src="<?php echo e(asset('storage/'.$file->filepath)); ?>"
                                     width="140" height="100"
                                     class="rounded-md border border-gray-200 object-cover">
                            <?php endif; ?>
                            <div class="absolute top-1 right-1 bg-white/90 rounded-md shadow p-1">
                                <input type="checkbox" name="hapus_file[]" value="<?php echo e($file->id); ?>" class="cursor-pointer">
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-gray-500 text-sm">Belum ada file untuk produk ini.</p>
                    <?php endif; ?>
                </div>
                <p class="text-gray-500 text-sm mt-1">Centang file yang ingin dihapus.</p>
            </div>

            
            <div>
                <label for="files" class="block text-gray-700 font-semibold mb-1">Tambah File Baru</label>
                <input id="files" name="files[]" type="file" multiple accept="image/*,video/*"
                       class="w-full border-gray-300 rounded-lg focus:ring-[#007daf] focus:border-[#007daf] bg-white py-2 px-3">
                <?php $__errorArgs = ['files.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <small class="text-gray-500">Kamu dapat memilih beberapa file (foto/video) sekaligus.</small>
            </div>

            
            <div id="preview-area" class="hidden">
                <label class="block text-gray-700 font-semibold mb-1">Preview File Baru</label>
                <div id="preview-list" class="flex flex-wrap gap-3"></div>
            </div>

            
            <div>
                <label for="harga" class="block text-gray-700 font-semibold mb-1">Harga (Rp)</label>
                <input type="number" id="harga" name="harga" min="0"
                       value="<?php echo e(old('harga', $produk->harga)); ?>"
                       class="w-full border-gray-300 rounded-lg focus:ring-[#007daf] focus:border-[#007daf]"
                       required>
                <?php $__errorArgs = ['harga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="flex justify-between items-center pt-4">
                <a href="<?php echo e(route('penjual.produk.index')); ?>"
                   class="px-4 py-2 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded-lg transition">
                    ← Batal
                </a>
                <button type="submit"
                        class="px-5 py-2 bg-gradient-to-r from-[#007daf] via-[#c771d4] to-[#ffb829] text-white font-semibold rounded-lg hover:scale-105 transition">
                    💾 Simpan Perubahan
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const input = document.getElementById('files');
    const previewArea = document.getElementById('preview-area');
    const previewList = document.getElementById('preview-list');

    input.addEventListener('change', function () {
        previewList.innerHTML = '';

        const files = Array.from(this.files);
        if (!files.length) {
            previewArea.classList.add('hidden');
            return;
        }

        previewArea.classList.remove('hidden');

        files.forEach(file => {
            const url = URL.createObjectURL(file);
            const ext = file.name.split('.').pop().toLowerCase();

            const wrapper = document.createElement('div');
            wrapper.classList.add('w-36', 'border', 'rounded-lg', 'p-2', 'text-center', 'shadow-sm');

            if (['mp4','mov','webm','avi'].includes(ext)) {
                const video = document.createElement('video');
                video.src = url;
                video.width = 140;
                video.height = 100;
                video.controls = true;
                video.classList.add('rounded-md', 'object-cover');
                wrapper.appendChild(video);
            } else {
                const img = document.createElement('img');
                img.src = url;
                img.width = 140;
                img.height = 100;
                img.classList.add('rounded-md', 'object-cover');
                wrapper.appendChild(img);
            }

            const name = document.createElement('p');
            name.classList.add('text-gray-600', 'text-sm', 'mt-2');
            name.textContent = file.name.length > 20 ? file.name.slice(0,17) + '...' : file.name;
            wrapper.appendChild(name);

            previewList.appendChild(wrapper);
        });
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.penjual', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\giftkita-2\resources\views/penjual/produk/edit.blade.php ENDPATH**/ ?>