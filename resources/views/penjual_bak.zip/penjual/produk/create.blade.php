@extends('layouts.penjual')

@section('title', 'Tambah Produk | GiftKita')

@section('content')
<section class="max-w-4xl mx-auto px-6 py-12">
    <h1 class="text-3xl font-bold text-gray-800 mb-6">🛍 Tambah Produk Baru</h1>

    <form action="{{ route('penjual.produk.store') }}" method="POST" enctype="multipart/form-data" class="space-y-6 bg-white p-6 rounded-2xl shadow-md">
        @csrf

        <div>
            <label class="block text-sm font-medium text-gray-700">Nama Produk</label>
            <input type="text" name="nama_produk" class="w-full border border-gray-300 rounded-xl p-3 focus:ring-2 focus:ring-[#007daf]" required>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Deskripsi</label>
            <textarea name="deskripsi" rows="4" class="w-full border border-gray-300 rounded-xl p-3 focus:ring-2 focus:ring-[#c771d4]"></textarea>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Harga</label>
            <input type="number" name="harga" step="0.01" class="w-full border border-gray-300 rounded-xl p-3 focus:ring-2 focus:ring-[#ffb829]" required>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Foto Produk (bisa lebih dari satu)</label>
            <input type="file" name="foto[]" multiple accept="image/*" class="w-full border border-gray-300 rounded-xl p-3 focus:ring-2 focus:ring-[#007daf]">
        </div>

        <div class="flex justify-end">
            <button type="submit" class="px-6 py-3 rounded-xl text-white font-semibold bg-gradient-to-r from-[#007daf] via-[#c771d4] to-[#ffb829] hover:scale-105 transition">Simpan Produk</button>
        </div>
    </form>
</section>
@endsection
