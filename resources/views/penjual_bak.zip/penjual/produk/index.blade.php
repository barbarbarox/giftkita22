@extends('layouts.penjual')

@section('content')
<div class="p-6">
    <h1 class="text-2xl font-semibold mb-4">Daftar Produk</h1>
    <a href="{{ route('penjual.produk.create') }}" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
        + Tambah Produk
    </a>

    <table class="table-auto w-full mt-6 border-collapse">
        <thead class="bg-gray-100">
            <tr>
                <th class="border px-4 py-2">Nama Produk</th>
                <th class="border px-4 py-2">Harga</th>
                <th class="border px-4 py-2">Stok</th>
                <th class="border px-4 py-2">Aksi</th>
            </tr>
        </thead>
        <tbody>
            @foreach($produks as $produk)
            <tr>
                <td class="border px-4 py-2">{{ $produk->nama_produk }}</td>
                <td class="border px-4 py-2">Rp {{ number_format($produk->harga, 0, ',', '.') }}</td>
                <td class="border px-4 py-2">{{ $produk->stok }}</td>
                <td class="border px-4 py-2">
                    <a href="{{ route('penjual.produk.edit', $produk->uuid) }}" class="text-blue-500 hover:underline">Edit</a>
                    <form action="{{ route('penjual.produk.destroy', $produk->uuid) }}" method="POST" class="inline">
                        @csrf @method('DELETE')
                        <button class="text-red-500 hover:underline ml-2" onclick="return confirm('Yakin ingin hapus?')">
                            Hapus
                        </button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
