@extends('layouts.penjual')

@section('content')
<div class="p-6 max-w-lg mx-auto">
    <h1 class="text-2xl font-semibold mb-4">Tambah Toko Baru</h1>

    <form action="{{ route('penjual.toko.store') }}" method="POST">
        @csrf
        <div class="mb-4">
            <label class="block">Nama Toko</label>
            <input type="text" name="nama_toko" class="w-full border p-2 rounded" required>
        </div>

        <div class="mb-4">
            <label class="block">Alamat</label>
            <input type="text" name="alamat_toko" class="w-full border p-2 rounded">
        </div>

        <div class="mb-4">
            <label class="block">Deskripsi</label>
            <textarea name="deskripsi" class="w-full border p-2 rounded"></textarea>
        </div>

        <div class="mb-4">
            <label class="block">Sosial Media</label>
            <input type="text" name="sosial_media" class="w-full border p-2 rounded">
        </div>

        <button class="bg-blue-600 text-white px-4 py-2 rounded">Simpan</button>
    </form>
</div>
@endsection
