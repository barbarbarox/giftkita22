@extends('layouts.penjual')

@section('content')
<div class="p-6">
    <h1 class="text-2xl font-semibold mb-4">Daftar Toko</h1>
    <a href="{{ route('penjual.toko.create') }}" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
        + Tambah Toko
    </a>

    <table class="table-auto w-full mt-6 border-collapse">
        <thead class="bg-gray-100">
            <tr>
                <th class="border px-4 py-2">Nama Toko</th>
                <th class="border px-4 py-2">Alamat</th>
                <th class="border px-4 py-2">Aksi</th>
            </tr>
        </thead>
        <tbody>
            @foreach($tokos as $toko)
            <tr>
                <td class="border px-4 py-2">{{ $toko->nama_toko }}</td>
                <td class="border px-4 py-2">{{ $toko->alamat_toko }}</td>
                <td class="border px-4 py-2">
                    <a href="{{ route('penjual.toko.edit', $toko->uuid) }}" class="text-blue-500 hover:underline">Edit</a>
                    <form action="{{ route('penjual.toko.update', $toko->uuid) }}" method="POST" class="inline">
                        @csrf @method('DELETE')
                        <button class="text-red-500 hover:underline ml-2" onclick="return confirm('Yakin ingin hapus?')">
                            Hapus
                        </button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
