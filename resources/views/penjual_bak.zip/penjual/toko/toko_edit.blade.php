@extends('layouts.penjual')

@section('content')
<div class="p-6 max-w-lg mx-auto">
    <h1 class="text-2xl font-semibold mb-4">Edit Data Toko</h1>

    <form action="{{ route('penjual.toko.update', $toko->uuid) }}" method="POST">
        @csrf @method('PUT')

        <div class="mb-4">
            <label class="block">Nama Toko</label>
            <input type="text" name="nama_toko" class="w-full border p-2 rounded" value="{{ $toko->nama_toko }}" required>
        </div>

        <div class="mb-4">
            <label class="block">Alamat</label>
            <input type="text" name="alamat_toko" class="w-full border p-2 rounded" value="{{ $toko->alamat_toko }}">
        </div>

        <div class="mb-4">
            <label class="block">Deskripsi</label>
            <textarea name="deskripsi" class="w-full border p-2 rounded">{{ $toko->deskripsi }}</textarea>
        </div>

        <div class="mb-4">
            <label class="block">Sosial Media</label>
            <input type="text" name="sosial_media" class="w-full border p-2 rounded" value="{{ $toko->sosial_media }}">
        </div>

        <button class="bg-green-600 text-white px-4 py-2 rounded">Perbarui</button>
    </form>
</div>
@endsection
