@extends('layouts.penjual')

@section('content')
    <h1 class="text-2xl font-bold text-gray-800">Halaman ini masih dalam pengembangan.</h1>
@endsection
